﻿using Exercice1_Common;
using System;
using System.ServiceModel;

namespace Exercice1
{
    class TaskCreator
    {
        private static ChannelFactory<ITaskManager> channelFactory;
        private static ITaskManager remoteTaskManager;

        static void Main(string[] args)
        {
            channelFactory = new ChannelFactory<ITaskManager>("TaskManager");
            channelFactory.Open();

            remoteTaskManager = channelFactory.CreateChannel();

            Console.WriteLine("> Client TaskCreator started.");
            Console.WriteLine("> Press ANY KEY to create and send 200 random Tasks.");
            Console.Write("> ");
            Console.ReadLine();

            while (true)
            {
                for (int i = 0; i < 200; i++)
                {
                    ExoTask task = ExoTask.RandomExoTask();
                    remoteTaskManager.AddTask(task);
                }
                Console.WriteLine("> 200 tasks sent.");
                Console.ReadLine();
            }
        }
    }
}
