﻿using System;
using System.Runtime.Serialization;

namespace Exercice1_Common
{
    /// <summary>
    /// ExoTask structure representing the datas sent to the ExoTaskManager.
    /// </summary>
    [DataContract]
    public class ExoTask
    {
        static public Random randomizer;

        static private int newID;
        static private int NewID {
            get 
            {
                ExoTask.newID++;
                return ExoTask.newID;
            }
        }

        private int taskID;
        [DataMember]
        public int TaskID
        {
            get
            {
                return this.taskID;
            }
            set
            {
                this.taskID = value;
            }
        }

        /// <summary>
        /// There is 4 types of Tasks.
        /// </summary>
        private int taskType;
        [DataMember]
        public int TaskType
        {
            get
            {
                return this.taskType;
            }
            set
            {
                this.taskType = value;
            }
        }

        /// <summary>
        /// Duration of Task, in ms.
        /// </summary>
        private int duration;
        [DataMember]
        public int Duration
        {
            get
            {
                return this.duration;
            }
            set
            {
                this.duration = value;
            }
        }

        /// <summary>
        /// If TaskManager is set to take it into account, priority can be setup so Manager can run first the most prioritized tasks.
        /// </summary>
        private int priority;
        [DataMember]
        public int Priority
        {
            get
            {
                return this.priority;
            }
            set
            {
                this.priority = value;
            }
        }

        static ExoTask()
        {
            ExoTask.randomizer = new Random();
        }

        public ExoTask(int cType, int cDuration, int cPriority)
        {
            this.TaskID = ExoTask.NewID;
            this.TaskType = cType;
            this.Duration = cDuration;
            this.Priority = cPriority;
        }

        static public ExoTask RandomExoTask(int maxDuration = 5000, int priority = -1)
        {
            int cType = ExoTask.randomizer.Next(1, 4);
            int cDuration = ExoTask.randomizer.Next(10, maxDuration);
            int cPriority = priority;
            if (priority == -1)
            {
                cPriority = ExoTask.randomizer.Next(0, 100);
            }

            return new ExoTask(cType, cDuration, cPriority);
        }
    }
}
