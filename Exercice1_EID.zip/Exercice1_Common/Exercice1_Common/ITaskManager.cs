﻿using System.ServiceModel;

namespace Exercice1_Common
{
    [ServiceContract]
    public interface ITaskManager
    {
        [OperationContract]
        void AddTask(ExoTask exoTask);
    }
}
