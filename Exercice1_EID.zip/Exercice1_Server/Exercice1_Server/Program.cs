﻿using Exercice1_Common;
using System;
using System.ServiceModel;

namespace Exercice1_Server
{
    class Server
    {
        private static ServiceHost server;
        private static ExoTaskManager taskManager;

        static void Main(string[] args)
        {
            // Uncommented next line to test Singleton correctness by causing the program to fail.
            // taskManager = new ExoTaskManager();
            try
            {
                taskManager = new ExoTaskManager();
            }
            catch (ExoTaskManagerAlreadyInstantiatedException)
            {
                MonitorDisplay.DisplayLine(0, "Task Manager instantiation failed. Only one Task Manager can be instantiated.");
                MonitorDisplay.DisplayLine(1, "Press ANY KEY to stop TaskManager.");
                Console.ReadLine();
            }
            taskManager.StartWorkers();

            server = new ServiceHost(taskManager);
            server.Open();
            MonitorDisplay.DisplayLine(0, "Server hosting TaskManager started.");
            MonitorDisplay.DisplayLine(1, "Press ANY KEY to stop TaskManager.");
            Console.ReadLine();
            
            server.Close();
            taskManager.StopWorkers();
            MonitorDisplay.DisplayLine(0, "Server hosting TaskManager stopped.");
            MonitorDisplay.DisplayLine(1, "Press ANY KEY to exit Program.");
            Console.ReadLine();
        }
    }
}
