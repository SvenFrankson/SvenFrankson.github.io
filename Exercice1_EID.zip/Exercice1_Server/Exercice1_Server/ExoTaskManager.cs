﻿using Exercice1_Common;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Threading;

namespace Exercice1_Server
{
    /// <summary>
    /// Singleton pattern implementation exception.
    /// </summary>
    public class ExoTaskManagerAlreadyInstantiatedException : Exception
    {
        public ExoTaskManagerAlreadyInstantiatedException()
        {

        }

        public ExoTaskManagerAlreadyInstantiatedException(string message)
            : base(message)
        {

        }

        public ExoTaskManagerAlreadyInstantiatedException(string message, Exception inner)
            : base(message, inner)
        {

        }
    }

    /// <summary>
    /// ExoTaskManager creates Workers, starts associated WorkerThread, and keeps TaskList up to date.
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    class ExoTaskManager : ITaskManager
    {
        private int workersCount = 20;
        private List<Worker> workers;
        private List<ExoTask> taskPool;

        private DateTime startupTime = DateTime.MinValue;
        private int totalWorkDone;

        /// <summary>
        /// Stores the last ExoTaskManager instantiated.
        /// </summary>
        private static ExoTaskManager _instance;
        public static ExoTaskManager Instance
        {
            get
            {
                return _instance;
            }
        }

        /// <summary>
        /// Initializes instance properties.
        /// </summary>
        public ExoTaskManager()
        {
            // Singleton pattern. Throw an exception if an ExoTaskManager instance has already been created.
            if (ExoTaskManager._instance != null)
            {
                throw new ExoTaskManagerAlreadyInstantiatedException();
            }
            ExoTaskManager._instance = this;
            this.taskPool = new List<ExoTask>();
            this.workers = new List<Worker>();
        }

        public void InitializeClock()
        {
            if (this.startupTime == DateTime.MinValue)
            {
                this.startupTime = DateTime.Now;
            }
        }

        /// <summary>
        /// Creates and starts [workersCount] workers.
        /// </summary>
        public void StartWorkers()
        {
            for (int i = 0; i < workersCount; i++)
            {
                Worker worker = new Worker();
                this.workers.Add(worker);
                Thread workerThread = new Thread(worker.Start);
                workerThread.Start();
            }
        }

        /// <summary>
        /// Sends a Stop message to all workers, thus causing them to stop at the end of their current task.
        /// </summary>
        public void StopWorkers()
        {
            foreach (Worker worker in this.workers)
            {
                worker.Stop();
            }
        }

        /// <summary>
        /// Adds a task to the taskPool and orders the taskPool so workers pick the prioritize task.
        /// </summary>
        /// <param name="task"></param>
        public void AddTask(ExoTask task)
        {
            this.InitializeClock();
            lock (taskPool)
            {
                taskPool.Add(task);
                // See README for details about the taskPool sorting strategy.
                //taskPool.Sort((t1, t2) => t1.Priority.CompareTo(t2.Priority));
                taskPool.Sort((t1, t2) => t2.Duration.CompareTo(t1.Duration));
            }
            ExoTaskManager.Instance.UpdatePoolDisplay();
        }

        /// <summary>
        /// Pops and returns the first task of the taskPool.
        /// </summary>
        /// <returns></returns>
        public ExoTask PopTask()
        {
            ExoTask task = null;
            lock (taskPool)
            {
                if (taskPool.Count > 0)
                {
                    task = taskPool[0];
                    taskPool.RemoveAt(0);
                }
            }
            ExoTaskManager.Instance.UpdatePoolDisplay();
            return task;
        }

        /// <summary>
        /// Once task is done, worker may call AddWorkDone to keep track of accomplished work.
        /// Note : No lock here as addition is thread safe.
        /// </summary>
        /// <param name="task"></param>
        public void AddToWorkDone(ExoTask task)
        {
            this.totalWorkDone += task.Duration;
            UpdateTotalWorkDone();
        }

        /// <summary>
        /// Thread-safely write runtime information on the console output.
        /// </summary>
        #region MonitorDisplayUpdate
        public void UpdatePoolDisplay()
        {
            MonitorDisplay.DisplayLine(2, "TaskPool Size      : " + taskPool.Count + "          ");
        }

        public void UpdateTotalWorkDone()
        {
            int workingTime = (int)(DateTime.Now - startupTime).TotalMilliseconds;
            MonitorDisplay.DisplayLine(3 + this.workers.Count, "Total Work Done    : " + (totalWorkDone / 1000) + " s        ");
            MonitorDisplay.DisplayLine(4 + this.workers.Count, "Time Since Startup : " + (workingTime / 1000) + " s        ");
            MonitorDisplay.DisplayLine(5 + this.workers.Count, "Ratio              : " + ((float)totalWorkDone / workingTime).ToString("0.00") + "          ");
        }
        #endregion
    }
}
