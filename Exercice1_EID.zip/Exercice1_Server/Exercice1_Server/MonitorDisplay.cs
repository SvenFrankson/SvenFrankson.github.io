﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice1_Server
{
    /// <summary>
    /// Accessor to the shared console output.
    /// Required to avoid public mutex as two classes (ExoTaskManager and Worker) might be sending display messages.
    /// </summary>
    public class MonitorDisplay
    {
        // Console accessor mutex.
        private static readonly object consoleLock = new object();
        private static int width;

        /// <summary>
        /// Initializes console size.
        /// </summary>
        static MonitorDisplay()
        {
            lock (consoleLock)
            {
                Console.WindowHeight = 30;
                MonitorDisplay.width = Console.WindowWidth;
            }
        }

        /// <summary>
        /// Display a line at a given position.
        /// </summary>=
        /// <param name="top">Cursor line. 0 being the first line.</param>
        /// <param name="message">Message to display.</param>
        public static void DisplayLine(int top, string message)
        {
            // Cut only one-line displayable part of message.
            if (message.Length > MonitorDisplay.width)
            {
                message = message.Substring(0, MonitorDisplay.width);
            }
            // Create padding string so end of line is erased (avoid ghost characters).
            string padding = new string(' ', MonitorDisplay.width - message.Length);
            lock (consoleLock)
            {
                Console.SetCursorPosition(0, top);
                Console.Write(message + padding);
            }
        }
    }
}
