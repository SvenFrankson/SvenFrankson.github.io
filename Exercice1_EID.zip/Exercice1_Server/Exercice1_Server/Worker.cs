﻿using Exercice1_Common;
using System;
using System.Collections.Generic;
using System.Threading;

namespace Exercice1_Server
{
    /// <summary>
    /// A Worker instance runs ExoTask it has picked from the ExoTaskManager.
    /// </summary>
    public class Worker
    {
        private static int _newID;
        private static int newID
        {
            get
            {
                Worker._newID++;
                return Worker._newID;
            }
        }

        private int _workerID;
        public int WorkerID
        {
            get
            {
                return this._workerID;
            }
            set
            {
                this._workerID = value;
            }
        }

        // While a task is being processed, percentage of task done (updated every 500 ms)
        private int progress;
        // CurrentTask is null while Worker is waiting, otherwise it's the task the worker is working on.
        private ExoTask _currentTask;
        private ExoTask currentTask
        {
            get
            {
                return this._currentTask;
            }
            set
            {
                this._currentTask = value;
                this.UpdateWorkerStatusDisplay();
            }
        }
        // Set to true to stop worker after currentTask is processed.
        private bool stop;

        /// <summary>
        /// Initializes instance properties.
        /// </summary>
        public Worker()
        {
            this.WorkerID = Worker.newID;
            this.stop = true;
            this.currentTask = null;
        }

        /// <summary>
        /// Main Worker loop : Pop task, process, pop task, process...
        /// </summary>
        public void Start()
        {
            this.stop = false;
            while (!stop)
            {
                this.currentTask = ExoTaskManager.Instance.PopTask();
                this.DoCurrentTask();
            }
        }

        /// <summary>
        /// Task processing method.
        /// </summary>
        public void DoCurrentTask()
        {
            if (currentTask != null)
            {
                // Following lines are equivalent to Thread.Sleep(currentTask.Duration).
                // For display purpose, Duration is sliced in 500ms steps, thus enabling console refresh.
                bool done = false;
                int timeLeft = currentTask.Duration;
                while (!done)
                {
                    int sleepDelay = Math.Min(timeLeft, 500);
                    timeLeft -= sleepDelay;
                    this.progress = (currentTask.Duration - timeLeft) * 100 / currentTask.Duration;
                    this.UpdateWorkerStatusDisplay();
                    Thread.Sleep(sleepDelay);
                    done = (timeLeft == 0);
                }
                // Once task is completed, send it to ExoTaskManager for statistic purpose.
                ExoTaskManager.Instance.AddToWorkDone(currentTask);
                currentTask = null;
                this.UpdateWorkerStatusDisplay();
            }
            else
            {
                // If no task has been assigned, Worker goes idle for 50 ms, avoiding unnecessary CPU cycles : Pop null task, do nothing, pop null task, do nothing...
                // Idle delay should be chosen small against typical task Duration. Here, 50ms vs 2500 ms.
                Thread.Sleep(50);
            }
        }

        /// <summary>
        /// Set stop to true, causing the worker to stop after its current task is completed.
        /// </summary>
        public void Stop()
        {
            this.stop = true;
        }

        /// <summary>
        /// Thread-safely write runtime information on the console output.
        /// </summary>
        #region MonitorDisplayUpdate
        public void UpdateWorkerStatusDisplay()
        {
            string statusString = "";
            if (currentTask != null)
            {
                statusString = "   Worker #" + this.WorkerID.ToString("00") + "      : T" + currentTask.TaskType + " (" + this.progress + " %)          ";
            }
            else
            {
                statusString = "   Worker #" + this.WorkerID.ToString("00") + "      : Waiting.          ";
            }
            MonitorDisplay.DisplayLine(2 + this.WorkerID, statusString);
        }
        #endregion
    }
}
